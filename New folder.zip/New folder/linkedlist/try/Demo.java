public class Demo{
    public static void main(String[] args) {
        Imp i=new Imp();
        i.insertAtBeginning(3);
        i.insertAtBeginning(4);
        //i.display();
        i.insertAtBeginning(6);
        i.insertAtBeginning(7);
        i.display();
    }
}
