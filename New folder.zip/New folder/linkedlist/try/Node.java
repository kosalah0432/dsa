public class Node{
    int data;
    Node next;
     public Node(int val)
     {
        data=val;
        next=null;
     }
}
