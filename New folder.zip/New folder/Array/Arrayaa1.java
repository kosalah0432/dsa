import java.util.ArrayList;
import java.util.Arrays;

public class Arrayaa1 {
    public static void main(String[] args) {
        int[] arr = {2, 3, 4, 5, 6, 7, 8, 9, 10};
        ArrayList<Integer> arrlist = new ArrayList<>(Arrays.asList(arr));

        System.out.println(arrlist);
    }
}
