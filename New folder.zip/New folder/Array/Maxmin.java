public class Maxmin {
    
}
